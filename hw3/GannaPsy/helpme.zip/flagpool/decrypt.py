import os
from pwn import *
keyfile=open("key.file").read()
keynum=0
whitelist=["GannaPsy.py","decrypt.py","key.file"]
for dirPath, dirNames, fileNames in os.walk("."):
	fileNames.sort()
	for files in fileNames:
		if files in whitelist:
			continue
		print files
		origin=open(files).read()
		key=keyfile[keynum*8:(keynum+1)*8]
		print key.encode("hex")
		keynum+=1
		ori=xor(origin,key)
		f=open(files,"w")
		f.write(ori)
		f.close()
